import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component'; 
import { ReactiveFormsModule } from "@angular/forms";
import { SearchComponent } from './search/search.component';
import { HttpClientModule } from '@angular/common/http';
import { RequestComponent } from './blood-availability/request/request.component';
import { DetailsComponent } from './details/details.component';
import { BloodPostComponent } from './blood-post/blood-post.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    SearchComponent,
    RequestComponent,
    DetailsComponent,
    BloodPostComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
