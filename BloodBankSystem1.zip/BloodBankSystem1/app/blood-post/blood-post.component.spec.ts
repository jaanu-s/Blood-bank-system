import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BloodPostComponent } from './blood-post.component';

describe('BloodPostComponent', () => {
  let component: BloodPostComponent;
  let fixture: ComponentFixture<BloodPostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BloodPostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BloodPostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
