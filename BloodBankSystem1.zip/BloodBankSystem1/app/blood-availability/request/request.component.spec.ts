import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { request } from 'src/app/blood-availability/request/request';
import { RequestComponent } from './request.component';
import { Component, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";

describe('RequestComponent', () => {
  let component: RequestComponent;
  let fixture: ComponentFixture<RequestComponent>;
  let submitEl: DebugElement;
  let cityE1: DebugElement;
  let stateE1: DebugElement;
  let bloodE1: DebugElement;
  let pincodeE1: DebugElement;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RequestComponent]
    })
      .compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(RequestComponent);
    component = fixture.componentInstance;
    submitEl = fixture.debugElement.query(By.css('input[id=btnSubmit]'));
    cityE1 = fixture.debugElement.query(By.css('input[id=city]'));
    stateE1 = fixture.debugElement.query(By.css('input[id=state]'));
    pincodeE1 = fixture.debugElement.query(By.css('input[id=pincode]'));
    bloodE1 = fixture.debugElement.query(By.css('input[id=bloodGroup]'));

  }));
  it('Setting value to input properties on form load', () => {
    component.enabled = false;
    fixture.detectChanges();
    expect(submitEl.nativeElement.disabled).toBeTruthy();
  });
  it('Setting value to input properties on button click', () => {
    component.enabled = true;
    fixture.detectChanges();
    expect(submitEl.nativeElement.disabled).toBeFalsy();
  });
  it('Entering value in input controls and emit output events', () => {
    let user: request = {
      id: 0,
      name: "",
      bloodGroup: "",
      city: "",
      contactNumber: "",
      pincode: 0,
      state: ""
    };
    pincodeE1.nativeElement.value = 600001;
    stateE1.nativeElement.value = "Tamil Nadu";
    cityE1.nativeElement.value = "Chennai";
    bloodE1.nativeElement.value = "O+";
    // Subscribe to the Observable and store the user in a local variable.
    component.onSubmit().subscribe((value) => this.user = value);
    // This sync emits the event and the subscribe callback gets executed above
    submitEl.triggerEventHandler('click', null);
    // Now we can check to make sure the emitted value is correct
    expect(user.name).toBe("Mythili");

  });
});