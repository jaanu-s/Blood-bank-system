import { Component, OnInit } from '@angular/core';
import { request } from 'src/app/blood-availability/request/request';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserAuthServiceService } from 'src/app/services/user-auth-service.service';
import { AuthenticationServiceService } from 'src/app/services/authentication-service.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
request:request = {
  id:0,
  state : "",
  city : "",
  pincode:0,
  name:"",
  bloodGroup:"",
  contactNumber:""
};  
  isLogged: boolean;
  userName: string = this.authService.getUserName();
 postForm: FormGroup;
  constructor(private router:Router , private userService:UserAuthServiceService,
  private authService:AuthenticationServiceService) { }

  ngOnInit() { this.postForm = new FormGroup({
      'bloodGroup': new FormControl('', [
        Validators.required
      ]),
      'city': new FormControl('', [
        Validators.required
      ]),
      'pincode': new FormControl('', [
        Validators.required
      ]),
     
      'state': new FormControl('', [
        Validators.required
      ]),
       'name': new FormControl('', [
        Validators.required
         ]),
        'contactNumber': new FormControl('', [
        Validators.required
      ]),
       });
    this.postForm.get('bloodGroup').valueChanges.subscribe(value => this.request.bloodGroup = value);
    this.postForm.get('city').valueChanges.subscribe(value => this.request.city = value);
    this.postForm.get('pincode').valueChanges.subscribe(value => this.request.pincode = value);
    this.postForm.get('state').valueChanges.subscribe(value => this.request.state = value);
    this.postForm.get('name').valueChanges.subscribe(value => this.request.name = value);
    this.postForm.get('contactNumber').valueChanges.subscribe(value => this.request.contactNumber = value);
     this.isLogged = this.authService.isLogged();
    this.userName = this.authService.getUserName();
  }
  get bloodGroup() { return this.postForm.get('bloodGroup'); }
  get city() { return this.postForm.get('city'); }
  get pincode() { return this.postForm.get('pincode'); }
   get state() { return this.postForm.get('state'); }
   get name() { return this.postForm.get('name'); }
  get contactNumber() { return this.postForm.get('contactNumber');
 }
  
    onSubmit() {
    console.log(this.request);
    this.userService.addRequest(this.request).subscribe();
    alert("Your Blood Requirements are posted successfully on the home page");
    this.router.navigateByUrl("/search");
  
  }
    logout() {
    this.authService.logout();
    this.userName = this.authService.getUserName();
    this.router.navigateByUrl("/login");
  }
    

}
