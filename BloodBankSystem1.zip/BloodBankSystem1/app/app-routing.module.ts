import { NgModule, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { SearchComponent } from "./search/search.component";
import { RequestComponent } from "./blood-availability/request/request.component";
import { DetailsComponent } from "./details/details.component";
import { BloodPostComponent } from "./blood-post/blood-post.component";

const routes: Routes = [
 
  {path:"search",component:SearchComponent},
  { path: "",
    redirectTo: "/search",
    pathMatch: "full"
  },
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
    {path:"request",component:RequestComponent},
    {path:"details",component:DetailsComponent},
    {path:"blood-post",component:BloodPostComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
