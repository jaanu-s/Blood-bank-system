import { Component, OnInit } from '@angular/core';
import { UserList } from '../userList';
import { AuthenticationServiceService } from 'src/app/services/authentication-service.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  authenticated: boolean = true;
 
  loggedUser: UserList;
    isLogged: boolean;
  userName: string = this.authenticationService.getUserName();
  constructor(private authenticationService : AuthenticationServiceService,public router: Router) { }

  ngOnInit() {
    this.loggedUser = {
     
    userName: "",
    lastName: "",
    blood: "",
    city: "",
    gender: "",
    password: "",
    age: 0,
    weight: 0,
    contact: "",
    email: "",
    pincode: 0,
    state: ""
  }
   this.isLogged = this.authenticationService.isLogged();
    this.userName = this.authenticationService.getUserName();
  }


  onLogin() {
    console.log(this.loggedUser.userName);
    this.authenticationService.authenticateUser(this.loggedUser.userName, this.loggedUser.password);

   
  }
    logout() {
    this.authenticationService.logout();
    this.userName = this.authenticationService.getUserName();
    this.router.navigateByUrl("/login");
  }

  }

