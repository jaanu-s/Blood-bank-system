import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserList } from '../userList';
import { SignupComponent } from './signup.component';
import {Component, DebugElement} from "@angular/core";
import {By} from "@angular/platform-browser";

describe('SignupComponent', () => {
  let component: SignupComponent;
  let fixture: ComponentFixture<SignupComponent>;
  let submitEl: DebugElement;
  let userNameEl: DebugElement;
  let lastNameE1 : DebugElement;
  let passwordE1 : DebugElement;
   let cityE1 : DebugElement;
    let stateE1 : DebugElement;
    let weightE1 : DebugElement;
    let bloodE1 : DebugElement;
    let pincodeE1 : DebugElement;
    let contactE1 : DebugElement;
    let ageE1 : DebugElement;
    let genderE1 : DebugElement;
    let emailE1 : DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SignupComponent);
    component = fixture.componentInstance;
    submitEl = fixture.debugElement.query(By.css('input[id=btnSubmit]'));
    userNameEl = fixture.debugElement.query(By.css('input[id=userName]'));
    lastNameE1 = fixture.debugElement.query(By.css('input[id=lastName]'));
    passwordE1 = fixture.debugElement.query(By.css('input[id=password]'));
   /* cityE1 = fixture.debugElement.query(By.css('input[id=city]'));
    stateE1 = fixture.debugElement.query(By.css('input[id=state]'));
    pincodeE1 = fixture.debugElement.query(By.css('input[id=pincode]'));
    contactE1 = fixture.debugElement.query(By.css('input[id=contact]'));
    ageE1 = fixture.debugElement.query(By.css('input[id=age]'));
    genderE1 = fixture.debugElement.query(By.css('input[id=gender]'));
    weightE1 = fixture.debugElement.query(By.css('input[id=weight]'));
   emailE1 = fixture.debugElement.query(By.css('input[id=email]'));
   bloodE1 = fixture.debugElement.query(By.css('input[id=blood]'));
    */
  }));
 it('Setting value to input properties on form load', () => {
    component.enabled = false;
    fixture.detectChanges();
   // expect(submitEl.nativeElement.disabled).toBeTruthy();
  });
  it('Setting value to input properties on button click', () => {
    component.enabled = true;
    fixture.detectChanges();
   // expect(submitEl.nativeElement.disabled).toBeFalsy();
  });
it('Entering value in input controls and emit output events', () => {
    let user: UserList = { 
    userName: "",
    lastName: "",
    blood: "",
    city: "",
    gender: "",
    password: "",
    age: 0,
    weight: 0,
    contact: "",
    email: "",
    pincode: 0,
    state: ""
  };
    userNameEl.nativeElement.value = "Mythili";
    passwordE1.nativeElement.value = "m";
    lastNameE1.nativeElement.value = "m";
   /* weightE1.nativeElement.value = 55;
    ageE1.nativeElement.value = 22;
    pincodeE1.nativeElement.value = 600001;
    stateE1.nativeElement.value = "Tamil Nadu";
    cityE1.nativeElement.value = "Chennai";
    contactE1.nativeElement.value = "8596471236";
    bloodE1.nativeElement.value = "O+";
   emailE1.nativeElement.value = "mythili";
   genderE1.nativeElement.value = "Female";*/
    // Subscribe to the Observable and store the user in a local variable.
    component.onSubmit().subscribe((value) => this.user = value);
    // This sync emits the event and the subscribe callback gets executed above
    submitEl.triggerEventHandler('click', null);
    // Now we can check to make sure the emitted value is correct
    expect(user.userName).toBe("Mythili");
    expect(user.password).toBe("m");
    expect(user.lastName).toBe("m");
   
  });
});