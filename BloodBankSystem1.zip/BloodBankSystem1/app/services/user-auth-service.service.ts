import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserList } from '../site/userList';
import { environment } from "src/environments/environment";
import {AuthGuardService} from './auth-guard.service';
import { Router } from '@angular/router';
import {request } from '../blood-availability/request/request';

@Injectable({
  providedIn: 'root'
})
export class UserAuthServiceService {
 
  private baseUrl = environment.baseUrl;
  private baseUrl1 =  'http://localhost:8087/blood-service/request';
  private baseUrl2 =  'http://localhost:8087/blood-service';
  constructor(private httpClient:HttpClient,private service :AuthGuardService , private router:Router) { }
  addUser(newuser:UserList){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.service.getToken() 
      })
    };
    console.log("Adduser" + newuser);
    return this.httpClient.post(`${this.baseUrl}/users`,newuser,httpOptions);
  }
search(pincode:number,bloodGroup:string): Observable<any> {
  const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    console.log("heloo");
    return this.httpClient.get(this.baseUrl1+'/'+pincode+'/'+bloodGroup, httpOptions);
}  
addRequest(request:request) {
  const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.service.getToken() 
      })
    };
    console.log("Addrequester" + request);
       return this.httpClient.post(`${this.baseUrl1}/add`,request,httpOptions);
}
getAllRequest(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    return this.httpClient.get(this.baseUrl2+ "/get", httpOptions);
  }
}

