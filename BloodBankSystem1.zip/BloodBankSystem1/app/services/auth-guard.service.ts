import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {
 token: string;
  id:number;
  private authenticationApiUrl = 'http://localhost:8087/authentication-service/authenticate';
  constructor(private httpClient:HttpClient) { }
   authenticate(user: string, password: string): Observable<any>{
    console.log("service called");
    let credentials = btoa(user + ':' + password);
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + credentials);
    return this.httpClient.get(this.authenticationApiUrl, {headers})
  }

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }
  public setId(id:number){
    this.id = id;
  }
  public getId(){
    return this.id;
  }
}
