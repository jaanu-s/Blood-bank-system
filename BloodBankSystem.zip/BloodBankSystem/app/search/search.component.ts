import { Component, OnInit } from '@angular/core';
import { UserList } from '../site/userList';
import { Router } from "@angular/router";
import { AuthenticationServiceService } from '../services/authentication-service.service';
import { UserAuthServiceService } from '../services/user-auth-service.service';
import { request } from 'src/app/blood-availability/request/request';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  request: request = {
    id: 0,
    state: "",
    city: "",
    pincode: 0,
    name: "",
    bloodGroup: "",
    contactNumber: ""
  };
val:String;
  isLogged: boolean;
  userName: string = this.service2.getUserName();

  constructor(private userService: UserAuthServiceService, private service2: AuthenticationServiceService,
    private router: Router)
  { }

  ngOnInit() {
    this.userService.getAllRequest().subscribe(
      data => {
      
        this.request = data;
        console.log(this.request);
      }
    );
    this.isLogged = this.service2.isLogged();
    this.userName = this.service2.getUserName();

  }
  logout() {
    this.service2.logout();
    this.userName = this.service2.getUserName();
    this.router.navigateByUrl("/login");
  }

}
