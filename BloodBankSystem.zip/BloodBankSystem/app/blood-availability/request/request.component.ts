import { Component, OnInit } from '@angular/core';
import { request } from './request';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserAuthServiceService } from 'src/app/services/user-auth-service.service';
import { AuthenticationServiceService } from 'src/app/services/authentication-service.service';
@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
request:request = {
  id:0,
  state : "",
  city : "",
  pincode:0,
  name:"",
  bloodGroup:"",
  contactNumber:""
};
  isLogged: boolean;
  userName: string = this.authService.getUserName();
found:boolean=false;

 requestForm: FormGroup;
  constructor(public router: Router, private userService:UserAuthServiceService,
  private authService:AuthenticationServiceService) { }

  ngOnInit() { this.requestForm = new FormGroup({
      'bloodGroup': new FormControl('', [
        Validators.required
      ]),
      'city': new FormControl('', [
        Validators.required
      ]),
      'pincode': new FormControl('', [
        Validators.required
      ]),
     
      'state': new FormControl('', [
        Validators.required
      ]),
     
    });
    this.requestForm.get('bloodGroup').valueChanges.subscribe(value => this.request.bloodGroup = value);
    this.requestForm.get('city').valueChanges.subscribe(value => this.request.city = value);
    this.requestForm.get('pincode').valueChanges.subscribe(value => this.request.pincode = value);
    this.requestForm.get('state').valueChanges.subscribe(value => this.request.state = value);
     this.isLogged = this.authService.isLogged();
    this.userName = this.authService.getUserName();
  }
  

  onSubmit() {
    console.log(this.request);
  if(this.authService.isLogged()) {
    this.userService.search(this.request.pincode,this.request.bloodGroup).subscribe(
      data=>{
        this.request=data;
            this.found=true;
      console.log(this.request)},
  
        error=>{
          this.router.navigateByUrl("/blood-post")
        });
  }
  }
 
  get bloodGroup() { return this.requestForm.get('bloodGroup'); }
  get city() { return this.requestForm.get('city'); }
  get pincode() { return this.requestForm.get('pincode'); }
   get state() { return this.requestForm.get('state'); }
     logout() {
    this.authService.logout();
    this.userName = this.authService.getUserName();
    this.router.navigateByUrl("/login");
  }
}