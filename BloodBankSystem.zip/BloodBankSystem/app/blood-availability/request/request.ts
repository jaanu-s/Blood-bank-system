export interface request {
    id:number;
    state :String;
    city:String;
    pincode:number;
    name:string;
    bloodGroup:string;
    contactNumber:String;
}
