import { Component, OnInit } from '@angular/core';
import { UserList } from '../userList';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserAuthServiceService } from 'src/app/services/user-auth-service.service';
import { Router } from '@angular/router';
import { AuthenticationServiceService } from 'src/app/services/authentication-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user: UserList = { 
    userName: "",
    lastName: "",
    blood: "",
    city: "",
    gender: "",
    password: "",
    age: 0,
    weight: 0,
    contact: "",
    email: "",
    pincode: 0,
    state: ""
  };
  userForm: FormGroup;
  passMatch: boolean;
  isLogged: boolean;
  userName1: string = this.service2.getUserName();
  constructor(private userService: UserAuthServiceService, public router: Router,private service2:AuthenticationServiceService) { }

  ngOnInit() {
    this.userForm = new FormGroup({
      'userName': new FormControl('', [
        Validators.required,
        Validators.pattern('^(?=.*[a-zA-Z])[a-zA-Z0-9]+$')
      ]),
      'lastName': new FormControl('', [
        Validators.required,
        Validators.pattern('^(?=.*[a-zA-Z])[a-zA-Z]+$')
      ]),
      'blood': new FormControl('', [
        Validators.required
      ]),
      'city': new FormControl('', [
        Validators.required
      ]),
      'gender': new FormControl('', [
        Validators.required,
      ]),
      'password': new FormControl('', [
        Validators.required,
        Validators.pattern('^(?=.*[a-zA-Z])[a-zA-Z0-9]+$')
      ]),
      'age': new FormControl('', [
        Validators.required
      ]),
       'weight': new FormControl('', [
        Validators.required
      ]),
      'contact': new FormControl('', [
        Validators.required
      ]),
       'email': new FormControl('', [
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]),
      'pincode': new FormControl('', [
        Validators.required
      ]),
     
      'state': new FormControl('', [
        Validators.required
      ]),
     
    });
    this.userForm.get('userName').valueChanges.subscribe(value => this.user.userName = value);
    this.userForm.get('lastName').valueChanges.subscribe(value => this.user.lastName = value);
    this.userForm.get('blood').valueChanges.subscribe(value => this.user.blood = value);
    this.userForm.get('city').valueChanges.subscribe(value => this.user.city = value);
    this.userForm.get('gender').valueChanges.subscribe(value => this.user.gender = value);
    this.userForm.get('password').valueChanges.subscribe(value => this.user.password = value);
    this.userForm.get('age').valueChanges.subscribe(value => this.user.age = value);
    this.userForm.get('weight').valueChanges.subscribe(value => this.user.weight = value);
    this.userForm.get('contact').valueChanges.subscribe(value => this.user.contact = value);
    this.userForm.get('email').valueChanges.subscribe(value => this.user.email = value);
    this.userForm.get('pincode').valueChanges.subscribe(value => this.user.pincode = value);
    this.userForm.get('state').valueChanges.subscribe(value => this.user.state = value);
    this.isLogged = this.service2.isLogged();
    this.userName1 = this.service2.getUserName();
  }
  onSubmit() {
    console.log(this.user);
    this.userService.addUser(this.user).subscribe();
   alert("New User Added Successfully");
    this.router.navigateByUrl('/login');
  }


  get userName() { return this.userForm.get('userName'); }
  get lastName() { return this.userForm.get('lastName'); }
  get blood() { return this.userForm.get('blood'); }
  get city() { return this.userForm.get('city'); }
  get gender() { return this.userForm.get('gender'); }
  get password() { return this.userForm.get('password'); }
  get age() { return this.userForm.get('age'); }
  get weight() { return this.userForm.get('weight'); }
  get contact() { return this.userForm.get('contact'); }
  get email() { return this.userForm.get('email'); }
  get pincode() { return this.userForm.get('pincode'); }
  get state() { return this.userForm.get('state'); }
  
  logout() {
    this.service2.logout();
    this.userName1 = this.service2.getUserName();
    this.router.navigateByUrl("/login");
  }
}

