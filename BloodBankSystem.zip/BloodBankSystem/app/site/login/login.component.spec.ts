import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserList } from '../userList';
import { LoginComponent } from './login.component';
import {Component, DebugElement} from "@angular/core";
import {By} from "@angular/platform-browser";

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let userNameEl: DebugElement;
  let passwordE1 : DebugElement;
  let submitEl: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(async(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    userNameEl = fixture.debugElement.query(By.css('input[id=userName]'));
    passwordE1 = fixture.debugElement.query(By.css('input[id=password]'));

  }));
 it('Setting value to input properties on form load', () => {
    component.enabled = false;
    fixture.detectChanges();
   expect(submitEl.nativeElement.disabled).toBeTruthy();
  });
  it('Setting value to input properties on button click', () => {
    component.enabled = true;
    fixture.detectChanges();
    expect(submitEl.nativeElement.disabled).toBeFalsy();
  });
it('Entering value in input controls and emit output events', () => {
    let user: UserList = { 
    userName: "",
    lastName: "",
    blood: "",
    city: "",
    gender: "",
    password: "",
    age: 0,
    weight: 0,
    contact: "",
    email: "",
    pincode: 0,
    state: ""
  };
    userNameEl.nativeElement.value = "Mythili";
    passwordE1.nativeElement.value = "m";
    component.onLogin().subscribe((value) => this.user = value);
    submitEl.triggerEventHandler('click', null);
    expect(user.userName).toBe("Mythili");
    expect(user.password).toBe("m");
    expect(user.lastName).toBe("m");
   
  });
});