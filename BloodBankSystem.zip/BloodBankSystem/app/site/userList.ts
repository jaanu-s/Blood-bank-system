export interface UserList {
    userName:string;
    lastName:String;
    blood:String;
    city:String;
    gender:String;
    password:string;
    age:number;
    weight:number;
    contact:String;
    email:String;
    pincode:number;
    state:String;
}