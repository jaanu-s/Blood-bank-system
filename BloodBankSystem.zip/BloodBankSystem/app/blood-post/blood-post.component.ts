import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationServiceService } from 'src/app/services/authentication-service.service';

@Component({
  selector: 'app-blood-post',
  templateUrl: './blood-post.component.html',
  styleUrls: ['./blood-post.component.css']
})
export class BloodPostComponent implements OnInit {
  find:boolean=false;
    isLogged: boolean;
  userName: string = this.service2.getUserName();

  post() {
      this.router.navigateByUrl("/details");
  }
  cancel() {
    this.router.navigateByUrl("/search");
  }
  constructor(private router:Router, private service2: AuthenticationServiceService ) { }

  ngOnInit() {
    this.isLogged = this.service2.isLogged();
    this.userName = this.service2.getUserName();
  }
    logout() {
    this.service2.logout();
    this.userName = this.service2.getUserName();
    this.router.navigateByUrl("/login");
  }
   
}

