import { Injectable } from '@angular/core';
import { UserAuthServiceService } from './user-auth-service.service';
import { Router } from '@angular/router';
import { AuthGuardService } from './auth-guard.service';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService {
  loggedInUser: boolean = false;
  loggedUserName: string;
  message:string="Invalid User";
  flag: boolean;
  error: string;
  constructor(private service: AuthGuardService, public router: Router) { }
  getUserName() {
    return this.loggedUserName;
  }
  logout() {
    this.loggedInUser = false;
    this.loggedUserName = "";
    this.service.setToken("");
  }
  isLogged() {
    return this.loggedInUser;
  }

  authenticateUser(username: string, password: string) {
    console.log("Authentication called");
    this.service.authenticate(username, password).subscribe(data => {
      this.service.setToken(data.token);
      this.service.setId(data.id)
      this.loggedUserName = username;
      this.loggedInUser = true;
      this.router.navigateByUrl('/search');
    },
      error => {
        console.log(error);
        if (error.status == 401) {
          this.error = "Invalid user ";
          console.log(this.error);
          alert(this.message);
          this.router.navigateByUrl('/login');
        }
      });


  }
}