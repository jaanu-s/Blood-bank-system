package com.cognizant.authentication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "us_id")
	private Integer id;

	@Column(name = "us_firstname")
	private String userName;
	
	@Column(name = "us_lastname")
	private String lastName;
	
	@Column(name = "us_age")
	private Integer age;
	
	@Column(name = "us_gender")
	private String gender;
	
	@Column(name = "us_contact_number")
	private String contact;
	
	@Column(name = "us_email")
	private String email;

	@Column(name = "us_password")
	private String password;
	
	@Column(name = "us_weight")
	private Integer weight;
	
	@Column(name = "us_state")
	private String state;
	
	@Column(name = "us_area")
	private String city;
	
	@Column(name = "us_pincode")
	private Integer pincode;
	
	@Column(name = "us_blood_group")
	private String blood;

	

	
	


	public User(Integer id, String userName, String lastName, Integer age,
			String gender, String contactNumber, String email, String password,
			Integer weight, String state, String city, Integer pincode,
			String blood) {
		super();
		this.id = id;
		this.userName = userName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contact = contactNumber;
		this.email = email;
		this.password = password;
		this.weight = weight;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.blood = blood;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/*public String getuserName() {
		return userName;
	}

	public void setuserName(String userName) {
		this.userName = userName;
	}*/

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	

	public String getEmail() {
		return email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", lastName="
				+ lastName + ", age=" + age + ", gender=" + gender
				+ ", contact=" + contact + ", email=" + email + ", password="
				+ password + ", weight=" + weight + ", state=" + state
				+ ", city=" + city + ", pincode=" + pincode + ", blood="
				+ blood + "]";
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBlood() {
		return blood;
	}

	public void setBlood(String blood) {
		this.blood = blood;
	}


	
}
