package com.cognizant.blood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.blood.model.Donors;

@Repository
public interface RequestRepository extends JpaRepository<Donors, Integer>{
	@Query(value = "SELECT * FROM bloodbank.donors "
			+ "   WHERE  do_pincode = ?  && do_blood_group = ? ", nativeQuery = true)
	List<Donors> getDonors(int pincode,String bloodGroup);




}
