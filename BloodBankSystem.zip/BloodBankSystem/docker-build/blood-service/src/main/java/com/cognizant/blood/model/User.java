package com.cognizant.blood.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "us_id")
	private Integer id;

	@Column(name = "us_firstname")
	private String firstName;
	
	@Column(name = "us_lastname")
	private String lastName;
	
	@Column(name = "us_age")
	private Integer age;
	
	@Column(name = "us_gender")
	private String gender;
	
	@Column(name = "us_contact_number")
	private String contactNumber;
	
	@Column(name = "us_email")
	private String email;

	@Column(name = "us_password")
	private String password;
	
	@Column(name = "us_weight")
	private Integer weight;
	
	@Column(name = "us_state")
	private String state;
	
	@Column(name = "us_area")
	private String area;
	
	@Column(name = "us_pincode")
	private Integer pincode;
	
	@Column(name = "us_blood_group")
	private String bloodGroup;



	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	
	
	

	
	

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName="
				+ lastName + ", age=" + age + ", gender=" + gender
				+ ", contactNumber=" + contactNumber + ", email=" + email
				+ ", password=" + password + ", weight=" + weight + ", state="
				+ state + ", area=" + area + ", pincode=" + pincode
				+ ", bloodGroup=" + bloodGroup + "]";
	}

	public User(Integer id, String firstName, String lastName, Integer age,
			String gender, String contactNumber, String email, String password,
			Integer weight, String state, String area, Integer pincode,
			String bloodGroup) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.email = email;
		this.password = password;
		this.weight = weight;
		this.state = state;
		this.area = area;
		this.pincode = pincode;
		this.bloodGroup = bloodGroup;
		
	}
	
	
}
