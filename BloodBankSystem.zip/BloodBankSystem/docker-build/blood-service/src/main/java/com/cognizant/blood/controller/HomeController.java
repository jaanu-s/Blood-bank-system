package com.cognizant.blood.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.blood.model.BloodDetails;
import com.cognizant.blood.service.RequsetService;

@RestController
@RequestMapping("/get")
public class HomeController {
	@Autowired
	private RequsetService requestService;
	
	@GetMapping()
    public List<BloodDetails> getAllRequest() {
    	return requestService.getAllRequest();
    }
}
