package com.cognizant.blood.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="request")
public class BloodDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "re_id")
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "re_name")
	private String name;
	@Column(name = "re_blood_group")
	private String bloodGroup;
	@Column(name = "re_state")
	private String state;
	@Column(name = "re_city")
	private String city;
	@Column(name = "re_pincode")
	private int pincode;
	@Column(name = "re_contact_number")
	private String contactNumber;
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "BloodDetails [id=" + id + ", name=" + name + ", bloodGroup="
				+ bloodGroup + ", state=" + state + ", area=" + city
				+ ", pincode=" + pincode + ", contactNumber=" + contactNumber
				+ "]";
	}
	public BloodDetails(int id, String name, String bloodGroup, String state,
			String city, int pincode, String contactNumber) {
		super();
		this.id = id;
		this.name = name;
		this.bloodGroup = bloodGroup;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.contactNumber = contactNumber;
	}
	public BloodDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	

}
