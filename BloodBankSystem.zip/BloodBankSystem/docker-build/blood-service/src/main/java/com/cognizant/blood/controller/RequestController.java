package com.cognizant.blood.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.blood.exception.BloodNotFoundException;
import com.cognizant.blood.model.BloodDetails;
import com.cognizant.blood.model.Donors;
import com.cognizant.blood.service.AppUserDetailsService;
import com.cognizant.blood.service.RequsetService;


@RestController
@RequestMapping("/request")
public class RequestController {
	@Autowired
	private RequsetService requestService;
	
	@Autowired
	AppUserDetailsService appUserDetailsService;
	
	@GetMapping("/{pincode}/{bloodGroup}")
	public List<Donors> getAllBloodDetails(@PathVariable int pincode,@PathVariable  String bloodGroup) throws BloodNotFoundException {
			return requestService.getDonors(pincode,bloodGroup);
	}	   
    @PostMapping("/add")
	public void addRequest(@RequestBody @Valid BloodDetails blood) throws Exception {
		requestService.addRequest(blood);
	}
    
    
}
