package com.cognizant.blood.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.blood.exception.UserAlreadyExistsException;
import com.cognizant.blood.model.AppUser;
import com.cognizant.blood.model.User;
import com.cognizant.blood.repository.UserRepository;

@Service
public class AppUserDetailsService implements UserDetailsService {

	@Autowired
	UserRepository userRepository;
	AppUser appUser;
	User user;

	public AppUserDetailsService() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		user = userRepository.findByFirstName(username);
		if (user == null)
			throw new UsernameNotFoundException("username not found");
		else
			appUser = new AppUser(user);
		return appUser;
	}

	@Transactional
	public void signup(User user) throws UserAlreadyExistsException {
		String pass = user.getPassword();
		user.setPassword(passwordEncoder().encode(pass));
		
		if (userRepository.findByFirstName(user.getFirstName()) != null) {
			throw new UserAlreadyExistsException();
		} else {
			userRepository.save(user);
		}

	}

	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
