package com.cognizant.blood.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="donors")
public class Donors {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "do_id")
	private int id;
	
	@Column(name = "do_name")
	private String name;
	@Column(name = "do_blood_group")
	private String bloodGroup;
	@Column(name = "do_state")
	private String state;
	@Column(name = "do_area")
	private String city;
	@Column(name = "do_pincode")
	private int pincode;
	@Column(name = "do_contact_number")
	private String contactNumber;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city= city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Donors(int id, String name, String bloodGroup, String state,
			String city, int pincode, String contactNumber) {
		super();
		this.id = id;
		this.name = name;
		this.bloodGroup = bloodGroup;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.contactNumber = contactNumber;
	}
	public Donors() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Donors [id=" + id + ", name=" + name + ", bloodGroup="
				+ bloodGroup + ", state=" + state + ", area=" + city
				+ ", pincode=" + pincode + ", contact=" + contactNumber + "]";
	}
	
}
