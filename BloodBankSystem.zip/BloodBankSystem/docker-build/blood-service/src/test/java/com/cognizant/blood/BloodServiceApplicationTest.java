/*package com.cognizant.blood;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;

import com.cognizant.blood.model.BloodDetails;
import com.cognizant.blood.repository.BloodDetailsRepository;
import com.cognizant.blood.service.RequsetService;

public class BloodServiceApplicationTest {

	private List<BloodDetails> list;

	@Test
	public void mockTestaddRequest() throws Exception {
		BloodDetails object =new BloodDetails(1,"K","Tamil Nadu","Chennai","9685741236",600001,"A+");
		BloodDetails bloodObject =new BloodDetails(2,"M","Andra","Hyderabed","9685746636",600008,"");
		List<BloodDetails> list = new ArrayList<BloodDetails>();
		list.add(object);
		list.add(bloodObject);
		BloodDetailsRepository repository = Mockito.mock(BloodDetailsRepository.class);
		when(repository.getAllRequest()).thenReturn(list);
		int expected =2;
		assertEquals(expected,list.size());
	}
	}

	
*/