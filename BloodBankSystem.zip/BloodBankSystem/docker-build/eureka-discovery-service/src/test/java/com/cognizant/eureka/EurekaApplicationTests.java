/*package com.cognizant.eureka;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaApplicationTests {

	@org.junit.Test
	void contextLoads() {
	}

}*/
