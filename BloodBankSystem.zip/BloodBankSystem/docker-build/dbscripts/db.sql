CREATE SCHEMA IF NOT EXISTS `bloodbank` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `bloodbank` ;

-- -----------------------------------------------------
-- Table `bloodbank`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bloodbank`.`user` (
  `us_id` INT NOT NULL AUTO_INCREMENT,
  `us_firstname` VARCHAR(50) NULL,
  `us_lastname` VARCHAR(50) NULL,
  `us_age` INT(2) NULL,
  `us_gender` VARCHAR(10) NULL,
  `us_contact_number` VARCHAR(10) NULL,
  `us_email` VARCHAR(45) NULL,
  `us_password` VARCHAR(60) NULL,
  `us_weight` INT(3) NULL,
  `us_state` VARCHAR(20) NULL,
  `us_area` VARCHAR(20)NULL,
  `us_pincode` INT(6) NULL,
  `us_blood_group` VARCHAR(5) NULL,
  PRIMARY KEY (`us_id`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Insert into Table `bloodbank`.`user`
-- -----------------------------------------------------
INSERT INTO `bloodbank`.`user` (us_id,us_firstname,us_lastname,us_age,us_gender,us_contact_number,us_email,us_password,us_weight,us_state,us_area,us_pincode,us_blood_group)
VALUES(1, 'pooja', 'sn', 22, 'Female', '9629842018', 'pujanandhu98@gmail.com', '$2a$10$OFaQgZhqrzv30bl/Kti1wevL1H.bWpzYRUWT3AkD1.1KYyNk2NYeG', 48, '1', 'Coimbatore', 636003, 'B+');

INSERT INTO `bloodbank`.`user`(us_id,us_firstname,us_lastname,us_age,us_gender,us_contact_number,us_email,us_password,us_weight,us_state,us_area,us_pincode,us_blood_group) 
	VALUES (5, 'sangee', 'sn', 34, 'Female', '8978905467', 'fgfhfhf', '$2a$10$3hHnke9bCCRjuroCDo/E3.MFmGpHKxX9j365yIpz.UZKGev1CcTDS', 55, '2', 'Hyderabed', 567890, 'O-');


-- -----------------------------------------------------
-- Table `bloodbank`.`donors`
-- ----------------------------------------------------
CREATE TABLE `bloodbank`.`donors` (
  `do_id` int(11) NOT NULL,
  `do_name` varchar(45) DEFAULT NULL,
  `do_blood_group` varchar(10) DEFAULT NULL,
  `do_area` varchar(45) DEFAULT NULL,
  `do_state` varchar(45) DEFAULT NULL,
  `do_pincode` int(11) DEFAULT NULL,
  `do_contact_number` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`do_id`)
) ENGINE=InnoDB ;



-- -----------------------------------------------------
-- Insert into Table `bloodbank`.`donors`
-- -----------------------------------------------------
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (1, 'keerthana', 'A+', 'Chennai', 'Tamil Nadu', 600001, '1236549870');
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (2, 'Shalini', 'B+', 'Coimbatore', 'Tamil Nadu', 600002, '8596472154');
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (3, 'Akila', 'B-', 'Hyderabed', 'Andra', 600003, '9889885569');
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (4, 'Pooja', 'O+', 'Vijayawada', 'Andra', 600004, '1258964755');
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (5, 'Gomala', 'O-', 'Kochi', 'Kerala', 600005, '6569854794');
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (6, 'Mythili', 'A-', 'Palakkad', 'Kerala', 600006, '9455667899');
INSERT INTO `bloodbank`.`donors` (`do_id`, `do_name`, `do_blood_group`, `do_area`, `do_state`, `do_pincode`, `do_contact_number`) VALUES (7, 'Seeni', 'O+', 'Chennai', 'Tamil Nadu', 600001, '9682785668');

-- -----------------------------------------------------
-- Table `bloodbank`.`request`
-- ----------------------------------------------------
CREATE  TABLE `bloodbank`.`request` (
  `re_id` INT NOT NULL AUTO_INCREMENT ,
  `re_name` VARCHAR(45) NULL ,
  `re_state` VARCHAR(45) NULL ,
  `re_city` VARCHAR(45) NULL ,
  `re_pincode` INT NULL ,
  `re_contact_number` VARCHAR(45) NULL ,
  `re_blood_group` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`re_id`) );

INSERT INTO `bloodbank`.`request` (`re_id`, `re_name`,`re_state`, `re_city`,`re_pincode`, `re_contact_number`,`re_blood_group`) VALUES (1, 'Sangeetha', '3', 'Palakkad', 600007, '8807651890', 'O-');
