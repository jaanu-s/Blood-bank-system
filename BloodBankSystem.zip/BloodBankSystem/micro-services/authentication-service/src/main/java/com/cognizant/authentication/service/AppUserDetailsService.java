package com.cognizant.authentication.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.authentication.exception.UserAlreadyExistsException;
import com.cognizant.authentication.model.AppUser;
import com.cognizant.authentication.model.User;
import com.cognizant.authentication.repository.UserRepository;

@Service
public class AppUserDetailsService implements UserDetailsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AppUserDetailsService.class);



	@Autowired
	UserRepository userRepository;

	AppUser appUser;
	User user;

	public AppUserDetailsService() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		user = userRepository.findByUserName(username);
		if (user == null)
			throw new UsernameNotFoundException("username not found");
		else
			appUser = new AppUser(user);
		return appUser;
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	public void signUp(User user2) throws Exception {

		//User check = userRepository.findByUserName(user2.getuserName());

		String pass = user2.getPassword();
		user2.setPassword(passwordEncoder().encode(pass));
		if (userRepository.findByUserName(user2.getUserName()) != null) {
			throw new Exception();
			}
		else
		{
			userRepository.save(user2);
		}
			
	

	}
	

}
