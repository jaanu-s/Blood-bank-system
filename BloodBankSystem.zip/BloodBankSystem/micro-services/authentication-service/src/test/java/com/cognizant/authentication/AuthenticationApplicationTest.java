package com.cognizant.authentication;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.cognizant.authentication.exception.UserAlreadyExistsException;
import com.cognizant.authentication.model.User;
import com.cognizant.authentication.repository.UserRepository;
import com.cognizant.authentication.service.AppUserDetailsService;

public class AuthenticationApplicationTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationApplicationTest.class);

	@Test
	public void mockTestLoadUserByUsername() {
		User user = new User();
		user.setId(5);
		user.setPassword("$2a$10$c1EGtqnO/Qr//hWM/LRGTug/5cuWQ3dXsKAHD3u8x7edMw0gJMsPq");
		user.setUserName("ff");
		user.setAge(56);
		user.setBlood("A+");
		user.setCity("Chennai");
		user.setContact("56676");
		user.setEmail("ryrtydgd");
		user.setGender("Male");
		user.setLastName("sn");
		user.setState("Tamil Nadu");
		user.setWeight(55);
		user.setPincode(4657);
		
		
		UserRepository repository = Mockito.mock(UserRepository.class);
		
		when(repository.findByUserName("ff")).thenReturn(user);
		AppUserDetailsService service= new AppUserDetailsService(repository);
		UserDetails us = service.loadUserByUsername("ff");
		String expected = "$2a$10$c1EGtqnO/Qr//hWM/LRGTug/5cuWQ3dXsKAHD3u8x7edMw0gJMsPq";
		assertEquals(expected, us.getPassword());
		System.out.println(us.getUsername());
		
	
		
		
	}
	

	@Test
	public void mockTestLoadByUserNameWithUserNull() {
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUserName("user")).thenReturn(null);
		UserDetailsService service = new AppUserDetailsService(repository);
		try {
			UserDetails user = service.loadUserByUsername("user");
			LOGGER.debug("user:{}", user);
		} catch (UsernameNotFoundException e) {
			LOGGER.error("User not found", e);
			assertTrue(true);
			return;
		}
		assertFalse(true);
	}
	@Test
	public void mockTestSignupNulluser() throws UserAlreadyExistsException {
		User user = new User();
		user.setId(8);
		user.setPassword("$2a$10$c1EGtqnO/Qr//hWM/LRGTug/5cuWQ3dXsKAHD3u8x7edMw0gJMsPq");
		user.setUserName("fh");
		user.setAge(56);
		user.setBlood("A+");
		user.setCity("Chennai");
		user.setContact("56676");
		user.setEmail("ryrtydgd");
		user.setGender("Male");
		user.setLastName("sn");
		user.setState("Tamil Nadu");
		user.setWeight(55);
		user.setPincode(4657);
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUserName("fh")).thenReturn(user);
		
		AppUserDetailsService service= new AppUserDetailsService (repository);
			try {
				repository.save(user);
				service.signUp(user);
			} catch (Exception e) {
				assertTrue(true);
				return;
			}
			assertFalse(true);
			
		}
	@Test
	public void mockTestSignUp() throws UserAlreadyExistsException {
		User user = new User();
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUserName("fh")).thenReturn(null);
		user.setId(8);
		user.setPassword("$2a$10$c1EGtqnO/Qr//hWM/LRGTug/5cuWQ3dXsKAHD3u8x7edMw0gJMsPq");
		user.setUserName("fh");
		user.setAge(56);
		user.setBlood("A+");
		user.setCity("Chennai");
		user.setContact("56676");
		user.setEmail("ryrtydgd");
		user.setGender("Male");
		user.setLastName("sn");
		user.setState("Tamil Nadu");
		user.setWeight(55);
		user.setPincode(4657);
		
		repository.save(user);
		AppUserDetailsService service= new AppUserDetailsService (repository);
			try {
				service.signUp(user);
				assertTrue(true);
				return;
			} catch (Exception e) {
				
				assertFalse(true);
			}	
			
		}	 
	}
