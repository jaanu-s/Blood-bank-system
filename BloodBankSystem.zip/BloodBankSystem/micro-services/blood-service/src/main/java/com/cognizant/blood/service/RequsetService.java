package com.cognizant.blood.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.blood.exception.BloodNotFoundException;
import com.cognizant.blood.model.BloodDetails;
import com.cognizant.blood.model.Donors;
import com.cognizant.blood.repository.BloodDetailsRepository;
import com.cognizant.blood.repository.RequestRepository;

@Service
public class RequsetService {
	

	@Autowired
	RequestRepository requestRepository;
	@Autowired
	BloodDetailsRepository bloodDetailRepository;
	
	public RequsetService(BloodDetailsRepository bloodDetailRepository) {
		super();
		this.bloodDetailRepository = bloodDetailRepository;
	}
	public RequsetService() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RequsetService(RequestRepository requestRepository) {
		super();
		this.requestRepository = requestRepository;
	}
	public List<Donors> getDonors(int pincode,String bloodGroup) throws BloodNotFoundException{
		//System.out.println( requestRepository.getDonors(pincode,bloodGroup));
		List<Donors> d =requestRepository.getDonors(pincode,bloodGroup);
		System.out.println(d);
		if (d.size() == 0) {
			
			System.out.println("inside exception");
			throw new BloodNotFoundException();
			}
		else
		{
			System.out.println("outside exception");
			//return requestRepository.getDonors(pincode,bloodGroup);
			return d;
		}
			
	}
	public void addRequest(BloodDetails blood) throws Exception {
	
		if(blood.getBloodGroup() == null ) {

		throw new Exception();
		}
		else {
			bloodDetailRepository.save(blood);
		}

	}
	public List<BloodDetails> getAllRequest() {
		return bloodDetailRepository.getAllRequest();
	}

	

}
