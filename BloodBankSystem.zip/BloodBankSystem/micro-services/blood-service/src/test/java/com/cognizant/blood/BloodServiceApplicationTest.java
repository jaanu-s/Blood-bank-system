package com.cognizant.blood;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.junit.Test;
import org.mockito.Mockito;

import com.cognizant.blood.exception.BloodNotFoundException;
import com.cognizant.blood.model.BloodDetails;
import com.cognizant.blood.model.Donors;
import com.cognizant.blood.repository.BloodDetailsRepository;
import com.cognizant.blood.repository.RequestRepository;
import com.cognizant.blood.service.RequsetService;

public class BloodServiceApplicationTest {

	private List<BloodDetails> list;
	private static final org.jboss.logging.Logger LOGGER = LoggerFactory.logger(BloodServiceApplicationTest.class);

	@Test
	public void mockTestaddRequest() throws Exception {
		BloodDetails bloodObject =new BloodDetails();
		bloodObject.setId(0);
		bloodObject.setName("K");
		bloodObject.setState("Tamil Nadu");
		bloodObject.setCity("Chennai");
		bloodObject.setContactNumber("9685741236");
		bloodObject.setPincode(600001);
		bloodObject.setBloodGroup("A+");
		List<BloodDetails> list = new ArrayList<BloodDetails>();
		list.add(bloodObject);
		BloodDetailsRepository repository = Mockito.mock(BloodDetailsRepository.class);
		when(repository.getAllRequest()).thenReturn(list);
		repository.save(list);
		List<BloodDetails> result = repository.getAllRequest();
		int expected =1;
	 
		assertEquals(expected,result.size());
		assertEquals("K",result.get(0).getName());
		assertEquals("Tamil Nadu",result.get(0).getState());
		assertEquals("Chennai",result.get(0).getCity());
		assertEquals("9685741236",result.get(0).getContactNumber());
		assertEquals(600001,result.get(0).getPincode());
		assertEquals("A+",result.get(0).getBloodGroup());
		
		RequsetService service= new RequsetService(repository);
		service.addRequest(bloodObject);
		String expected1 = "A+";
		assertEquals(expected1, service.getAllRequest().get(0).getBloodGroup());
		
	}
		
		@Test
		public void mockTestNulladdRequest() throws Exception {
			BloodDetails bloodObject =new BloodDetails();
			BloodDetailsRepository repository = Mockito.mock(BloodDetailsRepository.class);
			when(repository.save(bloodObject)).thenReturn(null);
			RequsetService service = new RequsetService(repository);
			try {
				service.addRequest(bloodObject);
			} catch (Exception e) {
				LOGGER.error("Exception", e);
				assertTrue(true);
				return;
			}
			assertFalse(true);
		}
		
	
		
		@Test
		public void mockGetDonors() throws BloodNotFoundException {
			Donors donor = new Donors();
			donor.setId(0);
			donor.setName("K");
			donor.setState("Tamil Nadu");
			donor.setCity("Chennai");
			donor.setContactNumber("9685741236");
			donor.setPincode(600001);
			donor.setBloodGroup("A+");
			List<Donors> list = new ArrayList<Donors>();
			list.add(donor);
			RequestRepository repository = Mockito.mock(RequestRepository.class);
			when(repository.getDonors(600001,"A+")).thenReturn(list);
			repository.save(list);
			List<Donors> result = repository.getDonors(600001,"A+");
			int expected =1;
			assertEquals(expected,result.size());
			assertEquals("K",result.get(0).getName());
			assertEquals("Tamil Nadu",result.get(0).getState());
			assertEquals("Chennai",result.get(0).getCity());
			assertEquals("9685741236",result.get(0).getContactNumber());
			assertEquals(600001,result.get(0).getPincode());
			assertEquals("A+",result.get(0).getBloodGroup());	
			RequsetService service= new RequsetService(repository);
			List<Donors> us = service.getDonors(600001, "A+");
			String expected1 = "A+";
			assertEquals(expected1, us.get(0).getBloodGroup());
		}
		
		@Test
		public void mockTestNullDonors() throws BloodNotFoundException {
			Donors donor = new Donors();
			donor.setId(0);
			donor.setName("K");
			donor.setState("Tamil Nadu");
			donor.setCity("Chennai");
			donor.setContactNumber("9685741236");
			donor.setPincode(600001);
			donor.setBloodGroup("A+");
			List<Donors> list = new ArrayList<Donors>();
			list.add(donor);	
			RequestRepository repository = Mockito.mock(RequestRepository.class);
			when(repository.getDonors(600051,"A1+")).thenReturn(list);
			RequsetService service= new RequsetService(repository);
	
			try {
				List<Donors> us = service.getDonors(600001, "A+");
				us.get(0);
			}
			catch(BloodNotFoundException e) {
				LOGGER.error("Requested Blood not found", e);
				assertTrue(true);
				return;
			}
			assertFalse(true);
		}
		
		
		
}







	
